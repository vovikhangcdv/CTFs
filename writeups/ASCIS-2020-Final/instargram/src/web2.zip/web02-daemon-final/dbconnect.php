<?php
	ini_set("session.cookie_httponly", 1);
	define('DBHOST', '###CENSORED###');
	define('DBUSER', '###CENSORED###');
	define('DBPASS', '###CENSORED###');
	define('DBNAME', '###CENSORED###');
	define('SALT', '###CENSORED###');
	define('SERVER_ROOT', '###CENSORED###');
	$conn = mysqli_connect(DBHOST,DBUSER,DBPASS,DBNAME);
	
	if ( !$conn ) {
		die("Connection failed : " . mysql_error());
	}
	
?>
